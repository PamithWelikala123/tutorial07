//1. Implement a Data Structure for Rational Number and create a method neg to class
//Rational that is used like this: x.neg
//evaluates to -x
object Question01 {
  def main(args: Array[String]): Unit = {

    class Rational(x:Int,y:Int)
    {
      val x1 = x
      val y1 = y

      def neg= new Rational(-this.x1,this.y1)
      def printOut = println(this.x1 + "/" + this.y1)
    }


      val x = new Rational(5,8)
      x.neg.printOut

  }
}

//2. Create a method sub to subtract two rational numbers and find an answer x-y-z where
//x=3/4, y=5/8, z=2/7.
object Question02 {
  def main(args: Array[String]): Unit = {
    def Solution(x1:Int,x2:Int,y1:Int,y2:Int,z1:Int,z2:Int):Unit={
      var gcd1=1
      val sol2=x2*y2*z2
      val sol1=(x1*sol2/x2)-(y1*sol2/y2)-(z1*sol2/z2)
      if(sol1<0 && sol2<0){
       gcd1=gcd(-sol1,-sol2)
      }
      else if(sol1>0 && sol2<0){
        gcd1=gcd(sol1,-sol2)
      }
      else if(sol1<0 && sol2>0){
        gcd1=gcd(-sol1,sol2)
      }
      else {
        gcd1=gcd(sol1,sol2)
      }
      println((sol1/gcd1)+"/"+(sol2/gcd1))
    }


    def gcd(a: Int, b: Int): Int = b match {
      case 0 => a
      case n => gcd(b, a % b)   // tail recursion
    }

    def Pass():Unit={
      println("Enter x :")

     var x=scala.io.StdIn.readLine()
      var x1=x(0)-48
      var x2=x(2)-48


      println("Enter y :")

      var y=scala.io.StdIn.readLine()
      var y1=y(0)-48
      var y2=y(2)-48

      println("Enter z :")

      var z=scala.io.StdIn.readLine()
      var z1=z(0)-48
      var z2=z(2)-48

      Solution(x1,x2,y1,y2,z1,z2)

    }
    Pass()

  }
}

//3. Implement a Data Structure for Account and create a method transfer which transfers the
//money from this account to a given account.
object Question03 {
  def main(args: Array[String]): Unit = {

    class Account(accId:Int,bal: Double = 0.0){

    val accountID = accId
    var balance = bal

    def withdraw(amount:Double) : Unit = {
        this.balance = this.balance - amount
    }

    def deposit(amount:Double) : Unit = {
        this.balance = this.balance + amount
    }

    def transfer(acc:Account, amount:Double) : Unit = {
        if (this.balance < 0.0) println("There is no balance")
        else {
            this.withdraw(amount)
            acc.deposit(amount)
        }
    }
}

        val acc1 = new Account(1, 1000.0)
        val acc2 = new Account(2, 2000.0)

        acc1.transfer(acc2, 500.0)
        println(acc1.balance)
        println(acc2.balance)

  }
}

//4. A Bank is defined as a List of Accounts. So implement the following functions:
//4.1 List of Accounts with negative balances
//4.2 Calculate the sum of all account balances
//4.3 Calculate the final balances of all accounts after apply the interest function as
//follows:
//If balance is positive, deposit interest is .05 and if balance is negative, overdraft interest is
//.1
object Question04 {
  def main(args: Array[String]): Unit = {
    class Account(accId: Int, bal: Double = 0.0) {

      val accountID = accId
      var balance = bal

      def withdraw(amount: Double): Unit = {
        this.balance = this.balance - amount
      }

      def deposit(amount: Double): Unit = {
        this.balance = this.balance + amount
      }

      def transfer(acc: Account, amount: Double): Unit = {
        if (this.balance < 0.0) println("Insufficient balance")
        else {
          this.withdraw(amount)
          acc.deposit(amount)
        }
      }

      var bank:List[Account] = List()

      def checkNegativeBalance(): Unit = {
        for (acc <- bank) {
          if (acc.balance < 0.0) println("Account ID: " + acc.accountID )
        }
      }

      def sumOfAllBalances() : Double = {
        var sum:Double = 0.0
        for (acc <- bank) {
          sum = sum + acc.balance
        }
        return sum
      }

      def finalBalance() : Unit = {
        var interest:Double = 0.05
        var overdraft:Double = 0.1

        for (acc <- bank) {
          if (acc.balance < 0.0) {
            acc.balance = acc.balance + (acc.balance * overdraft)
            println("Account ID: " + acc.accountID + " has a negative balance of " + acc.balance+" .Overdraft fee applied")
          }
          else {
            acc.balance = acc.balance + (acc.balance * interest)
            println("Account ID: " + acc.accountID + " has a positive balance of " + acc.balance)
          }
        }
      }

        var acc1 = new Account(1, 1000.0)
        var acc2 = new Account(2, 2500.0)
        var acc3 = new Account(3, 4600.0)
        var acc4 = new Account(4, 9430.0)
        var acc5 = new Account(5, 8000.0)
        var acc6 = new Account(6, -1000.0)
        var acc7 = new Account(7, -2000.0)
        var acc8 = new Account(8, -3000.0)
        var acc9 = new Account(9, -4000.0)
        var acc10 = new Account(10, -1000.0)

        bank = List(acc1, acc2, acc3, acc4, acc5, acc6, acc7, acc8, acc9, acc10)

        checkNegativeBalance()
        println("Sum of all balances: " + sumOfAllBalances())
        println("Final balance of all accounts")
        finalBalance()

    }
  }
}